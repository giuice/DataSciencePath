## 1. The JSON Format ##

import json
world_cup_str = """
[
    {
        "team_1": "France",
        "team_2": "Croatia",
        "game_type": "Final",
        "score" : [4, 2]
    },
    {
        "team_1": "Belgium",
        "team_2": "England",
        "game_type": "3rd/4th Playoff",
        "score" : [2, 0]
    }
]
"""
world_cup_obj = json.loads(world_cup_str)
world_cup_obj

## 2. Reading a JSON file ##

file = open('hn_2014.json')
hn = json.load(file)
hn[0]

## 3. Deleting Dictionary Keys ##

def del_key(dict_, key):
    # create a copy so we don't
    # modify the original dict
    modified_dict = dict_.copy()
    del modified_dict[key]
    return modified_dict
hn_clean = []
for dic in hn:
    hn_clean.append(del_key(dic,'createdAtI'))

hn_clean[0]

## 4. Writing List Comprehensions ##

# LOOP VERSION
#
# hn_clean = []
#
# for d in hn:
#     new_d = del_key(d, 'createdAtI')
#     hn_clean.append(new_d)
hn_clean = [del_key(d,'createdAtI')  for d in hn]

## 5. Using List Comprehensions to Transform and Create Lists ##

urls = [d['url'] for d in hn_clean]
urls[0:5]

## 6. Using List Comprehensions to Reduce a List ##

thousand_points = [d for d in hn_clean if d['points'] > 1000]
num_thousand_points = len(thousand_points)
num_thousand_points

## 7. Passing Functions as Arguments ##

def key_function(d):
    return d['numComments']
most_comments = max(hn_clean, key=key_function)
most_comments

## 8. Lambda Functions ##

# def multiply(a, b):
#    return a * b

multiply = lambda a,b: a*b
multiply(2,3)

## 9. Using Lambda Functions to Analyze JSON data ##

hn_sorted_points = sorted(hn_clean, key=lambda d: d['points'], reverse=True)
top_5_titles = [d['title'] for d in hn_sorted_points[0:5]]
top_5_titles

## 10. Reading JSON files into pandas ##

hn_df = pd.DataFrame(hn_clean)
hn_df.head(1)

## 11. Exploring Tags Using the Apply Function ##

tags = hn_df['tags']
four_tags = tags[tags.apply(len) > 3]
four_tags.head(1)

## 12. Extracting Tags Using Apply with a Lambda Function ##

# def extract_tag(l):
#     return l[-1] if len(l) == 4 else None
cleaned_tags = tags.apply(lambda d: d[-1] if len(d) == 4 else None)
hn_df['tags'] = cleaned_tags
